<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error="Invalid Username or Password";
		echo $error;
	}
	else
	{
		// Define $username and $password
		$user=$_POST['username'];
		$pass=$_POST['password'];
		$user_role = $_POST['radSize'];
		include('config.php'); //setting up the connection
		// To protect MySQL injection for Security purpose
		$username = stripslashes($username);
		$password = stripslashes($password);


	if($user_role == "admin"){

		$sql = "SELECT * FROM admin_reg where username='$user' and password='$pass'";

	}else{
		$sql = "SELECT * FROM exam_portal where username='$user' and password='$pass'";
	}
		
		$result = mysqli_query($conn, $sql);

		$rows  = mysqli_num_rows($result);
		  
		
		if ($rows == 1) {
			$_SESSION['login_user']=$user; // Initializing Session
			$_SESSION['user_role']=$user_role; // Initializing Session

			header("location: index.php"); 
			// Redirecting To Other Page
		} 
		else {
			$error="Invalid Username or Password";
			echo $error;
		}
mysqli_close($conn); // Closing Connection
}
}
