<?php
session_start();

$user_check=$_SESSION['login_user'];


if(!isset($user_check)){
	header('Location: index.php'); // Redirecting To Home Page
}
else{
	include('config.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN PROFILE | EDIFY</title>
	<link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div id="profile">
	<b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b>
	<b id="logout"><a href="logout.php">Log Out</a></b><br>
	<p style="font-size: 12px" align="left">
		<?php
			$sql = "SELECT * FROM exam_portal ";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				echo "<br> <br> <center> 
					<table border=1 cellspacing=5>
					<tr> <th> ID </th>
						 <th> SALUTATION</th>
						 <th> FIRST NAME</th>
						 <th>FATHER NAME</th>
						 <th>LAST NAME</th>
						 <th>GENDER</th>
						 <th>DOB</th>
						 <th>EMAIL</th>
						 <th>MOBILE NO. </th>
					</tr>";
					while($row = mysqli_fetch_assoc($result)) {
			        	echo "<tr><td> " . $row["id"]. " </td><td>" . $row["salutation"]." </td><td>". $row["fname"]." </td><td>". $row["father_fname"]. " </td><td>" . $row["lname"]." </td><td> " . $row["gender"]. " </td><td> " .$row["dob"]. " </td><td> " . $row["username"].  " </td><td> " . $row["mobile_no"]. "</td></tr>"; 
			    	}
			} 
			else {
			    echo "<tr><td colspan='9'>0 results</td></tr>";
			}
			echo "</table> </center>";

			//Close connection 
			mysqli_close($conn);
		?>
	</p>
</div>
</body>
</html>