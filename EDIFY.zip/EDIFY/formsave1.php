<?php
$a=$_POST["radSize"];
$b=$_POST["txt1"];
$c=$_POST["txt2"];
$d=$_POST["txt3"];
$e=$_POST["ts"];
$f=$_POST["Gen"];
$g=$_POST["txt4"];
$h=$_POST["txt5"];
$i=$_POST["txt6"];

include('config.php');

$sql = "INSERT INTO admin_reg (salutation, fname, mname, lname, dob, gender, mobile_no, username, password)
VALUES ('$a', '$b', '$c', '$d', '$e', '$f', '$g', '$h', '$i')";

if (mysqli_query($conn, $sql)) {
    $last_id = mysqli_insert_id($conn);
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn). "<br>";
}


//Close connection 
mysqli_close($conn);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ADMIN REGISTRATION | EDIFY UNIVERSITY</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style type="text/css">
.cc_div a:link, a:visited, a:hover, a:active
{
    color: grey;
}
div {
    display: block;
}
#wrapper {
    margin-left: 4%;
    width: 92%;
    height: 100%;
    margin-right: 4%;
}
#first {
    float:left;
    width: 92%;
    height: 20%;
    margin-left: 4%;
    margin-right: 4%;
    background:#f2f2f2 ;
}
</style>

</head> 
<body bgcolor=#f2f2f2>
<!-- Main Div -->
<div class="main_div" id="wrapper">
        <div class="a1_div" id="first"><br><br>
            <h1 style="color:white; background-color: #FFB2B2; text-align:center; margin-top: 10%">
                REGISTRATION FORM COMLETED AND SUBMITTED!!!
            </h1>
            <h1 style="color:white; background-color: #FF7F7F; text-align:center; margin-top: 20%">
                <a href="index.php"> LOGIN </a>
            </h1>
        </div>