<?php
		include('login.php'); // Includes Login Script
		if(isset($_SESSION['login_user'])){
			if($_SESSION['user_role'] == "admin")
			{
				header("location: admin_profile.php");
			}
			elseif($_SESSION['user_role'] == "user")
			{
				
				header("location: user_profile.php");
			}
		}
	?>
<!DOCTYPE html>
<html>
<head>
	<title> LOGIN | EDIFY </title>

	

	<link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#ececf0">
	<div id="main">
	<h1 align="center"> LOGIN FORM </h1><br>
	<center>
		<form name="frm" action="" method="POST">
				<label style="font-size: 18px;">UserName :</label>
				<input id="name" name="username" placeholder="username" type="text" required> <br>

				<label style="font-size: 18px;">Password :</label><br>
				<input id="password" name="password" placeholder="**********" type="password" required> <br>
				<p>
					<label style="font-size: 18px" for="radSize"> Role <font color="red"></font></label>
                	<input type = "radio" name = "radSize" id = "admin" value = "admin">
                	<label for = "admin" style="font-size: 18px;">Admin </label>
                	<input type = "radio" name = "radSize" id = "user" value = "user">
                	<label for = "user" style="font-size: 18px;">User</label>
           		</p>
                <p>
					<center>
						<input name="submit" type="submit" value=" Login ">
						<span><?php echo $error; ?></span>
					</center>
				</p>
		</form>
	</center>
	</div>
</body>
</html>