<?php
session_start();
include('config.php');

$user_check=$_SESSION['login_user'];

if(!isset($user_check)){
	header('Location: index.php'); // Redirecting To Home Page
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>USER PROFILE| EDIFY</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  	<link rel="stylesheet" type="text/css" href="css/qwerty.css">

</head>
<body>
	<div id="wrapper">
	<?php //echo $user_check; ?>
	<b id="logout"> <a href="logout.php">Log Out</a></b><br>
	<p>
	<?php
		//select data
		$sql = "SELECT * FROM exam_portal WHERE username='$user_check'";
		$result = mysqli_query($conn, $sql);
		$row=mysqli_fetch_assoc($result);
		if (mysqli_num_rows($result) > 0) {

			echo "<h1 align='center'> Personal info </h1>";
			echo "<h3 align='center' id='upper'> Basic info </h3> ";
			echo "<div class='row'>";
				echo "<div class='row' id='main'>";
					echo "<div class='row' id='sub1'> 
							<div class='col-xs-4'style='vertical-align:middle;'> <h2> Profile </h2> </div> 
							<div class='col-xs-4'>  </div>
							<div class='col-xs-4' id='subdiv3'>  </div>
						  </div>";
					echo "<div class='row' id='sub2'> 
							<div class='col-xs-4' id='subdiv1'> PHOTO  </div> 
							<div class='col-xs-4' id='subdiv2'></div>
							<div class='col-xs-4' id='subdiv3'> <img src='images/".$row["photo"]."' alt='HTML5 Icon' style='width:70px;height:70px; vertical-align: baseline;'> </div> </div> ";
					echo "<div class='row' id='sub2'> <a href='edit_profile/name.php?id=".$row["id"]."' alt='Edit Name'>
							<div class='col-xs-4' id='subdiv1'> NAME </div> 
							<div class='col-xs-4' id='subdiv2'> " . $row["salutation"] ." ". $row["fname"] . " " .  $row["lname"] . " </div> 
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div> 
						  </a></div>";
					echo "<div class='row' id='sub2'> 
							<div class='col-xs-4' id='subdiv1'> FATHER NAME </div> 
							<div class='col-xs-4' id='subdiv2'> Mr. " . $row["father_fname"]. " " .$row["lname"] . " </div> 
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div> 
						  </div>";
					echo "<div class='row' id='sub2'> 
							<div class='col-xs-4' id='subdiv1'> BIRTHDAY </div> 
							<div class='col-xs-4' id='subdiv2'> " . $row["dob"] . " </div> 
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div> 
						  </div>";
					echo "<div class='row' id='sub3'> 
							<div class='col-xs-4' id='subdiv1'> GENDER</div> 
							<div class='col-xs-4' id='subdiv2'> " . $row["gender"] . " </div> 
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div> 
						  </div>";
				echo "</div>";
				echo "<div class='row' id='main'>";
					echo "<div class='row' id='sub1'> <h2> Contact Info </h2> </div>";
					echo "<div class='row' id='sub2'> 
							<div class='col-xs-4' id='subdiv1'>  EMAIL </div> 
							<div class='col-xs-4' id='subdiv2a'> " . $row["username"] . " </div>
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div>
						  </div>";
					echo "<div class='row' id='sub3'> 
							<div class='col-xs-4' id='subdiv1'>  PHONE  </div> 
							<div class='col-xs-4' id='subdiv2'> " . $row["mobile_no"] . "</div>
							<div class='col-xs-4' id='subdiv3'> <i class='fa fa-chevron-right' aria-hidden='true'></i> </div>
						 </div>";
				echo "</div>";
			echo"</div>";
			}
		else {
			echo "<h1 align='center'> Personal info </h1>";
			echo "<h3 align='center'> Error loading your Profile </h3>";
		}
	//Close connection 
	mysqli_close($conn);
	?>
	</p>
</div>
</body>
</html>