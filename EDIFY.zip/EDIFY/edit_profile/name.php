<?php
	$id=$_GET['id'];

if (isset($_REQUEST['submit'])){
	$fname=$_REQUEST['fname'];
		$lname=$_REQUEST['lname'];

		include('../config.php');
		$sql = "UPDATE exam_portal set fname='$fname', lname='$lname' where id='$id'";

		if (mysqli_query($conn, $sql)) {
            header("Location: ../user_profile.php?id=".$id);
        } 
        else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn). "<br>";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title> NAME UPDATE</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  	<style type="text/css">
  		#logout {
			float:right;
			border:3px solid #eee;
			padding: 35px;
			font-size: 20px;
			margin: 1% 1% auto;
			background-color: white;
			}
  	</style>
</head>
<body>
	<div class='row'>
		<div class='col-xs-6' style="float: left; margin: auto;">
			<a href="index.html"><img src="https://edifyonline.files.wordpress.com/2011/08/edifywordpresslogo.jpg" width="180" height="100" style="margin-top:12px"></a>	
		</div>
		<div class='col-xs-6'>
			<b id="logout"> <a href="../logout.php">Log Out</a></b><br>
		</div>
	</div>
	<div class='row'>
		<div style="float: center; width: 40%; margin-left: 30%; margin-right: 30%">
			<div class="col-sm-2">
				<a href="../user_profile.php"> <i class="fas fa-arrow-left fa-2x"  style="float: right; padding-top: 30%; padding-bottom: 10%;"></i> </a>
			</div>	
			<div class="col-sm-10">
				<h2>
					Name
				</h2>
			</div>		
		</div>
	</div>
	<hr style="height:1px; color:black; background-color:black; width:100%; text-align:center; margin: 2% auto;">
</hr>
	<div class='row'>
		<div style="float: center; width: 40%; margin-left: 30%; margin-right: 30%">
			<form method="POST" action=" ">
			  <div class="row">
			    <div class="col-sm-6">
			      <input type="text" name="fname" class="form-control fa-2x" placeholder="First name"style="height: 50px;">
			    </div>
			    <div class="col-sm-6">
			      <input type="text" name="lname" class="form-control fa-2x" placeholder="Last name" style="height: 50px;">
			    </div>
			    <div class="row" >
			    	<input type="submit" name="submit" value="submit" style="float: center;">
			    </div>
			  </div>
			</form>
		</div>
	</div>
</body>
</html>