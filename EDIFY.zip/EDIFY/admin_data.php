<?php
//select data
$sql = "SELECT * FROM exam_portal ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	// output data of each row
	echo "<br> <br> <center> 
		<table border=1 cellspacing=5>
		<tr> <th> ID </th>
			 <th> SALUTATION</th>
			 <th> FIRST NAME</th>
			 <th>FATHER NAME</th>
			 <th>LAST NAME</th>
			 <th>GENDER</th>
			 <th>DOB</th>
			 <th>EMAIL</th>
			 <th>MOBILE NO. </th>
		</tr>";
		while($row = mysqli_fetch_assoc($result)) {
        	echo "<tr><td> " . $row["id"]. " </td><td>" . $row["salutation"]." </td><td>". $row["fname"]." </td><td>". $row["father_fname"]. " </td><td>" . $row["lname"]." </td><td> " . $row["gender"]. " </td><td> " .$row["dob"]. " </td><td> " . $row["username"].  " </td><td> " . $row["mobile_no"]. "</td></tr>"; 
    	}

	} 
else {
    echo "<tr><td colspan='9'>0 results</td></tr>";
}
echo "</table> </center>";

//Close connection 
mysqli_close($conn);

?>

